export const searchFormRefs = document.querySelector('#search-form');
export const outputRefs = document.querySelector('.gallery');
export const loadBtn = document.querySelector('.js-search');
