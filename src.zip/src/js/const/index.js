export const BASE_FETCH_URL = 'https://pixabay.com/api?';
export const API_KEY = '23297096-fdec21a8bcbab7faa251f0233';